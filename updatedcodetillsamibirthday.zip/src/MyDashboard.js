import React from 'react';
import ReactDOM from "react-dom";
import LogoComponent from './LogoComponent'
import CartComponent from './CartComponent'
import SearchComponent from './SearchComponent'
import MyAccountComponent from './MyAccountComponent';
import MenuComponent from './MenuComponent';
import FooterComponent from './FootComponent';
import StickyiconComponent from './StickyiconComponent';
import ShowcaseLayout from './ShowcaseLayout';
import { encode  } from "base-64";
import $ from "jquery"
import NotificationComponent from './NotificationComponent';


class MyDashboard extends React.Component {

    constructor(props) {
        super(props);
        this.state = { 
            layout: [] , 
            listApp:[],
            listOfNf_Uid:[],
            status:"",

            showConfig : false,
            name:"",
            url:"",
            cpu:"",
            memory:"",
            storage:"",
           
        };

        this.onLayoutChange = this.onLayoutChange.bind(this);
    }

    onLayoutChange(layout) {
        this.setState({ layout: layout });
    }

    stringifyLayout() {
        return this.state.layout.map(function (l) {
            return (
                <div className="layoutItem" key={l.i}>
                    <b>{l.i}</b>: [{l.x}, {l.y}, {l.w}, {l.h}]
                </div>
            );
        });
    }


    componentDidMount()
    {

        this.applicationList();
     
    }



    applicationList()
    {
        let authorization="";
        const loginData = {
            method: 'POST',
            headers: new Headers({
                'Content-Type': 'application/json'
            }),
            body: JSON.stringify(
                {
                    "username": "robin",
                    "password":"Robin@123",
                    "tenant":"Administrators"
                }
            )  
        };
    
        let url='https://10.151.35.44:29442/api/v3/robin_server/login';
        fetch(url,loginData)
        .then(response => {
    
            if (!response.ok) {
            console.log("response is not correct ");
            }
    
            return response.json();
        }).then(response => {
    
        authorization=response.token;

        let url = "https://10.151.35.44:29442/api/v6/robin_server/appsview";
        
        fetch(url, {
            method: 'GET',
            headers: new Headers({
                'Authorization': authorization,
                'Content-Type': 'application/json',
            })
        }).then(response => {

            if (!response.ok) {
            console.log(response);
            }

            return response.json();
        }).then(json => {
          
            let app = [];
            json.robin.apps.map((data, index)=>{
                !data.name.startsWith("mdcap") && data.name != "hostrepo" ? app.push({"name" : data.name,"status":data.state}) : console.log("else part " + data.name)
            })
          
            this.setState({
                listApp : app
            });
            console.log(this.state.listApp);
        });

        });
    }


    onBrowser(e,name)
    {
        e.preventDefault();
        let appValue="";
        let authorization="";
        const self=this;
        const loginData = {
            method: 'POST',
            headers: new Headers({
                'Content-Type': 'application/json'
            }),
            body: JSON.stringify(
                {
                    "username": "robin",
                    "password":"Robin@123",
                    "tenant":"Administrators"
                }
            )  
        };
    
        let url='https://10.151.35.44:29442/api/v3/robin_server/login';
        fetch(url,loginData)
        .then(response => {
    
            if (!response.ok) {
            console.log("response is not correct ");
            }
    
            return response.json();
        }).then(response => {
    
        authorization=response.token;

        appValue=name;

        let url = "https://10.151.35.44:29442/api/v6/robin_server/apps/"+appValue+"?info=true&details=vnodes";
        
        fetch(url, {
            method: 'GET',
            headers: new Headers({
                'Authorization': authorization,
                'Content-Type': 'application/json',
            })
        }).then(response => {

            if (!response.ok) {
            console.log(response);
            }

            return response.json();
        }).then(json => {
           
             let url=json.appinfo.service_urls[0].url
             let extractPartOfurl =url.split('//');
             let port=extractPartOfurl[1].split(':');
             let newIpPort="http://10.151.35.44:"+port[1]+"/";

            
            this.setState({
                name : json.ainstances[0].app,
                url : newIpPort,
                memory : json.mem,
                storage : json.ainstances[0].storage[0].size,
                cpu : json.ainstances[0].cpu_cores,
                showConfig : true,
            })

            window.open(this.state.url);
        });

        });

    }

    onSetting(e,name)
    {

        e.preventDefault();
        sessionStorage.setItem("selected-app", name);

        window.location.assign('/modifyResource');
        /*let username="admin";
        let password="admin";
    
        let authorization="";
        const loginData = {
            method: 'POST',
            headers: new Headers({
                'Authorization': 'Basic ' + encode(username + ":" +password ),
                'Content-Type': 'application/json'
            }),
            body: JSON.stringify(
                {
                    "userid": "admin",
                    "password":"admin"
                }
            )  
        };
    
        fetch('https://10.151.35.44:30540/engine/api/v1/login',loginData)
        .then(response => {
    
            if (!response.ok) {
            console.log("response is not correct ");
            }
    
            return response.json();
        }).then(response => {
    
        authorization=response.token;


        let url = "https://10.151.35.44:29442/api/v6/robin_server/appsview";
        
        fetch(url, {
            method: 'GET',
            headers: new Headers({
                'Authorization': authorization,
                'Content-Type': 'application/json',
            })
        }).then(response => {

            if (!response.ok) {
            console.log(response);
            }

            return response.json();
        }).then(json => {
            console.log(json.robin.apps)
            let app = [];
            json.robin.apps.map((data, index)=>{
                data.name != "mdcap" && data.name != "hostrepo" ? app.push(data.name) : console.log("else part " + data.name)
            })
            console.log(app)
            this.setState({
                listApp : app
            })
        });

        });*/
    }

    onStart(e,name,index)
    {
      
       const self=this;
       e.preventDefault();
       let loaderid = '#' + name +'-'+ index;
        $(loaderid).find(".td-status .badge b").text("STARTING");
        $(loaderid).find(".td-status .badge").removeAttr("style");
       
        let selectedApp = $("#application_name").attr("dataval");
        sessionStorage.setItem("selected-app", name);

        let interval;
        let username="admin";
        let password="admin";
    
        let nf_name=name;
        let nfId=sessionStorage.getItem(nf_name);
        
        let authorization="";
        const loginData = {
            method: 'POST',
            headers: new Headers({
                'Authorization': 'Basic ' + encode(username + ":" +password ),
                'Content-Type': 'application/json'
            }),
            body: JSON.stringify(
                {
                    "userid": "admin",
                    "password":"admin"
                }
            )  
        };
    
        fetch('https://10.151.35.44:30540/engine/api/v1/login',loginData)
        .then(response => {
    
            if (!response.ok) {
            console.log("response is not correct ");
            }
    
            return response.json();
        }).then(response => {
    
        authorization=response.token;

        let url = "https://10.151.35.44:30540/engine/api/v1/task/";
        
        fetch(url, {
            method: 'POST',
            headers: new Headers({
                'Authorization': authorization,
                'Content-Type': 'application/json',
                'X-Robin-Master' : '10.151.35.44'
            }),
            body: JSON.stringify(
                {
                    "workflow": "network-function-start",
                    "runtime_params": {
                      "1": {
                        "disabled": false,
                        "envs": {
                          "DCA_FN_IN": "reserved",
                          "DCA_FN_OUT": "reserved",
                          "UPDATE_PAYLOAD": "reserved",
                          "ACCESS_TOKEN": "reserved"
                        },
                        "element_uid":nfId
                      }
                    },
                    "topology": {
                      "nodes": [
                        {
                          "id": 1,
                          "y": 150,
                          "x": -500,
                          "type": "Start Network Function",
                          "fn_uid": "d0b174a6-7918-45f0-892b-e7d5e3178123",
                          "elem_uid": nfId,
                          "fn_envs": "",
                          "fn_description": "Start Network Function",
                          "fn_reserved_envs": "DCA_FN_IN,DCA_FN_OUT,UPDATE_PAYLOAD,ACCESS_TOKEN",
                          "displayIcon": true,
                          "label": "",
                          "predetermined_envs": {
                            "DCA_FN_IN": "reserved",
                            "DCA_FN_OUT": "reserved",
                            "UPDATE_PAYLOAD": "reserved",
                            "ACCESS_TOKEN": "reserved"
                          },
                          "hasElement": true,
                          "hasConfig": true,
                          "completed": false,
                          "status": null,
                          "disabled": false,
                          "isDebug": false,
                          "needsSetData": true,
                          "hasSetData": true
                        }
                      ],
                      "links": []
                    }
                  }
            )
        }).then(response => {

            if (!response.ok) {
            console.log(response);
            }

            return response.json();
        }).then(json => {

            console.log(json);
            let taskId=json.taskid;   
            interval = setInterval(function(){
            
             let url='https://10.151.35.44:30540/engine/api/v1/task/'+taskId+'?status=true';
    
           fetch(url,{
            method: 'GET',
            headers: new Headers({
                'Authorization': authorization,
            })
        })
        .then(response => {
    
            if (!response.ok) {
            }
            return response.json();
        }).then(response => {    
            
            let status1="";
       status1=response.summary.status;
       if (status1 === 'COMPLETED') {
        clearInterval(interval);
        $(".td-status .badge").css("display","none");
        self.applicationList();
    }
    if ( status1 === 'FAILED'){
        clearInterval(interval);
        $(".td-status .badge b").text("FAILED");
        $(".td-status .badge i").hide();
    } 
    });
    
    } , 5000);
    
        });
        });
    }

    onRestart(e,name,index)
    {

        const self=this;
        e.preventDefault();
        let loaderid = '#' + name +'-'+ index;
        $(loaderid).find(".td-status .badge b").text("RESTARTING");
        $(loaderid).find(".td-status .badge").removeAttr("style");

        sessionStorage.setItem("selected-app", name);

        let username="admin";
        let password="admin";
    
        let nf_name=name;
        let nfId=sessionStorage.getItem(nf_name);

        let interval;
        
        let authorization="";
        const loginData = {
            method: 'POST',
            headers: new Headers({
                'Authorization': 'Basic ' + encode(username + ":" +password ),
                'Content-Type': 'application/json'
            }),
            body: JSON.stringify(
                {
                    "userid": "admin",
                    "password":"admin"
                }
            )  
        };
    
        fetch('https://10.151.35.44:30540/engine/api/v1/login',loginData)
        .then(response => {
    
            if (!response.ok) {
            console.log("response is not correct ");
            }
    
            return response.json();
        }).then(response => {
    
        authorization=response.token;


        let url = "https://10.151.35.44:30540/engine/api/v1/task/";
        
        fetch(url, {
            method: 'POST',
            headers: new Headers({
                'Authorization': authorization,
                'Content-Type': 'application/json'
            }),
            body: JSON.stringify(
                {
                    "workflow": "network-function-redeploy",
                    "runtime_params": {
                    "1": {
                             "disabled": false,
                             "element_uid": nfId,
                         "envs": {
                             "DCA_FN_IN": "reserved",
                             "DCA_FN_OUT": "reserved",
                             "UPDATE_PAYLOAD": "reserved",
                             "ACCESS_TOKEN": "reserved"
                            }
                }
         },
            "topology": {
                "nodes": [
             {
                 "id": 1,
                  "y": 150,
                  "x": -500,
                  "type": "Re-deploy Network Function",
                 "fn_uid": "0476980f-3f0f-4b96-b1f3-7d6ce42ac030",
                 "elem_uid": nfId,
                 "fn_envs": "",
                 "fn_description": "Re-deploy Network Function",
                 "fn_reserved_envs": "DCA_FN_IN,DCA_FN_OUT,UPDATE_PAYLOAD,ACCESS_TOKEN",
                 "displayIcon": true,
                 "label": "",
                 "predetermined_envs": {
                 "DCA_FN_IN": "reserved",
                 "DCA_FN_OUT": "reserved",
                 "UPDATE_PAYLOAD": "reserved",
                 "ACCESS_TOKEN": "reserved"
           },
                 "hasElement": true,
                 "hasConfig": true,
                 "completed": false,
                "status": null,
                "disabled": false,
               "isDebug": false,
               "needsSetData": true,
               "hasSetData": true
        }
        ],
                "links": []
                    }
                }
            )
        }).then(response => {

            if (!response.ok) {
            console.log(response);
            }

            return response.json();
        }).then(json => {

            let taskId=json.taskid;   
            interval = setInterval(function(){
            
            let url='https://10.151.35.44:30540/engine/api/v1/task/'+taskId+'?status=true';
   
          fetch(url,{
           method: 'GET',
           headers: new Headers({
               'Authorization': authorization,
           })
       })
       .then(response => {
   
           if (!response.ok) {
           }
           return response.json();
       }).then(response => {    
        let status1="";
       status1=response.summary.status;
       if (status1 === 'COMPLETED') {
        clearInterval(interval);
        $(".td-status .badge").css("display","none");
        self.applicationList();
    }
    if ( status1 === 'FAILED'){
        clearInterval(interval);
        $(".td-status .badge b").text("FAILED");
        $(".td-status .badge i").hide();
    } 
    });

} , 5000);

        });
        });

    
    }

    onStop(e,name,index)
    {

        const self=this;
        e.preventDefault();
        let loaderid = '#' + name +'-'+ index;
        $(loaderid).find(".td-status .badge b").text("STOPPING");
        $(loaderid).find(".td-status .badge").removeAttr("style");
        let selectedApp = $("#application_name").attr("dataval");

        sessionStorage.setItem("selected-app", selectedApp);

        let nf_name=name;
        let nfId=sessionStorage.getItem(nf_name);

        let interval;
        let username="admin";
        let password="admin";
    
        let authorization="";
        const loginData = {
            method: 'POST',
            headers: new Headers({
                'Authorization': 'Basic ' + encode(username + ":" +password ),
                'Content-Type': 'application/json'
            }),
            body: JSON.stringify(
                {
                    "userid": "admin",
                    "password":"admin"
                }
            )  
        };
    
        fetch('https://10.151.35.44:30540/engine/api/v1/login',loginData)
        .then(response => {
    
            if (!response.ok) {
            console.log("response is not correct ");
            }
    
            return response.json();
        }).then(response => {
    
        authorization=response.token;


        let url = "https://10.151.35.44:30540/engine/api/v1/task/";
       
        fetch(url, {
            method: 'POST',
            headers: new Headers({
                'Authorization': authorization,
                'Content-Type': 'application/json',
                'X-Robin-Master' : '10.151.35.44'
            }),
            body: JSON.stringify(
                {
                    "workflow": "network-function-stop",
                    "runtime_params": {
                      "1": {
                        "disabled": false,
                        "envs": {
                          "DCA_FN_IN": "reserved",
                          "DCA_FN_OUT": "reserved",
                          "UPDATE_PAYLOAD": "reserved",
                          "ACCESS_TOKEN": "reserved"
                        },
                        "element_uid": nfId
                      }
                    },
                    "topology": {
                      "nodes": [
                        {
                          "id": 1,
                          "y": 150,
                          "x": -500,
                          "type": "Stop Network Function",
                          "fn_uid": "8424e9dc-a449-4ed4-961e-6915052e99ce",
                          "elem_uid": nfId,
                          "fn_envs": "",
                          "fn_description": "Stop Network Function",
                          "fn_reserved_envs": "DCA_FN_IN,DCA_FN_OUT,UPDATE_PAYLOAD,ACCESS_TOKEN",
                          "displayIcon": true,
                          "label": "",
                          "predetermined_envs": {
                            "DCA_FN_IN": "reserved",
                            "DCA_FN_OUT": "reserved",
                            "UPDATE_PAYLOAD": "reserved",
                            "ACCESS_TOKEN": "reserved"
                          },
                          "hasElement": true,
                          "hasConfig": true,
                          "completed": false,
                          "status": null,
                          "disabled": false,
                          "isDebug": false,
                          "needsSetData": true,
                          "hasSetData": true
                        }
                      ],
                      "links": []
                    }
                }
            )
        }).then(response => {

            if (!response.ok) {
            console.log(response);
            }

            return response.json();
        }).then(json => {
          
            let taskId=json.taskid;   
            interval = setInterval(function(){
            
            let url='https://10.151.35.44:30540/engine/api/v1/task/'+taskId+'?status=true';
   
          fetch(url,{
           method: 'GET',
           headers: new Headers({
               'Authorization': authorization,
           })
       })
       .then(response => {
   
           if (!response.ok) {
           }
           return response.json();
       }).then(response => {    
        let status1="";
        status1=response.summary.status;
        if (status1 === 'COMPLETED') {
            clearInterval(interval);
            $(".td-status .badge").css("display","none");
            self.applicationList();
        }
        if ( status1 === 'FAILED'){
            clearInterval(interval);
            $(".td-status .badge b").text("FAILED");
            $(".td-status .badge i").hide();
        } 
            
   });
   
   } , 5000);
        });
        });
    }


    onDelete(e,name,index)
    {
    
        const self=this;
        e.preventDefault();
        let loaderid = '#' + name +'-'+ index;
        $(loaderid).find(".td-status .badge b").text("DELETING");
        $(loaderid).find(".td-status .badge").removeAttr("style");
        let selectedApp = $("#application_name").attr("dataval");

        sessionStorage.setItem("selected-app", selectedApp);

        let nf_name=name;
        let nfId=sessionStorage.getItem(nf_name);
        let interval;
        let username="admin";
        let password="admin";
    
        let authorization="";
        const loginData = {
            method: 'POST',
            headers: new Headers({
                'Authorization': 'Basic ' + encode(username + ":" +password ),
                'Content-Type': 'application/json'
            }),
            body: JSON.stringify(
                {
                    "userid": "admin",
                    "password":"admin"
                }
            )
        
        };
    
        fetch('https://10.151.35.44:30540/engine/api/v1/login',loginData)
        .then(response => {
    
            if (!response.ok) {
            console.log("response is not correct ");
            }
    
            return response.json();
        }).then(response => {
    
            authorization=response.token;
    
             const terminationData = {
            method: 'POST',
            headers: new Headers({
                'Authorization': authorization ,
                'Content-Type': 'application/json'
            }),
            body: JSON.stringify(
                {
                    
                    "workflow": "network-function-termination",
                    "runtime_params": {
                      "1": {
                        "disabled": false,
                        "element_uid": nfId,
                        "envs": {
                          "DCA_FN_IN": "reserved",
                          "DCA_FN_OUT": "reserved",
                          "UPDATE_PAYLOAD": "reserved",
                          "ACCESS_TOKEN": "reserved"
                        }
                      }
                    },
                    "topology": {
                      "nodes": [
                        {
                          "id": 1,
                          "y": 150,
                          "x": -500,
                          "type": "Delete Network Function",
                          "fn_uid": "96e453ce-1f7e-457d-aa4a-afb13f10f942",
                          "elem_uid": nfId,
                          "fn_envs": "",
                          "fn_description": "Delete Network Function",
                          "fn_reserved_envs": "DCA_FN_IN,DCA_FN_OUT,UPDATE_PAYLOAD,ACCESS_TOKEN",
                          "displayIcon": true,
                          "label": "",
                          "predetermined_envs": {
                            "DCA_FN_IN": "reserved",
                            "DCA_FN_OUT": "reserved",
                            "UPDATE_PAYLOAD": "reserved",
                            "ACCESS_TOKEN": "reserved"
                          },
                          "hasElement": true,
                          "hasConfig": true,
                          "completed": false,
                          "status": null,
                          "disabled": false,
                          "isDebug": false,
                          "needsSetData": true,
                          "hasSetData": true
                        }
                      ],
                      "links": []
                    }
                }
            )
        };
    
       
        fetch('https://10.151.35.44:30540/engine/api/v1/task',terminationData)
        .then(response => {
    
            if (!response.ok) {
            console.log("response is not correct ");
            }
    
            return response.json();
        }).then(response => {
    
            let taskId=response.taskid;   
            interval = setInterval(function(){
            
            let url='https://10.151.35.44:30540/engine/api/v1/task/'+taskId+'?status=true';
   
          fetch(url,{
           method: 'GET',
           headers: new Headers({
               'Authorization': authorization,
           })
       })
       .then(response => {
   
           if (!response.ok) {
           }
           return response.json();
       }).then(response => {    
        let status1="";
       status1=response.summary.status;
        if(status1==='COMPLETED' |status1==='FAILED')
        {     
        
            clearInterval(interval);

            if(status1==='COMPLETED')
            {
                const deletDetails = {
                    method: 'DELETE',
                    headers: new Headers({
                        'Authorization': authorization,   
                    })
                };

                var baseurl = 'https://10.151.35.44:30540/engine/api/v1/network_function/'+nfId;
                fetch(baseurl, deletDetails)
                    .then(response => {
                
                    if (!response.ok) {
                        console.log(response);
                    }   
                    return response.status; 
        
                }).then(response =>{

                    if(response == 200 |response==202)
                    {
                            clearInterval(interval);
                            $(".td-status .badge").css("display","none");
                            self.applicationList();
                    }

                    if ( response >400){
                        clearInterval(interval);
                        $(".td-status .badge b").text("FAILED");
                        $(".td-status .badge i").hide();
                    } 
                        
                });
            }
        }  
            
   });
   
   } , 5000);
        });
    }); 
    }

    onGetNfId()
    {
        let username="admin";
        let password="admin";
    
        let authorization="";
        const loginData = {
            method: 'POST',
            headers: new Headers({
                'Authorization': 'Basic ' + encode(username + ":" +password ),
                'Content-Type': 'application/json'
            }),
            body: JSON.stringify(
                {
                    "userid": "admin",
                    "password":"admin"
                }
            )  
        };
    
        fetch('https://10.151.35.44:30540/engine/api/v1/login',loginData)
        .then(response => {
    
            if (!response.ok) {
            console.log("response is not correct ");
            }
    
            return response.json();
        }).then(response => {
    
        authorization=response.token;


        let url='https://10.151.35.44:30540/engine/api/v1/network_function';
   
        fetch(url,{
         method: 'GET',
         headers: new Headers({
             'Authorization': authorization,
         })
     })
     .then(response => {
 
         if (!response.ok) {
         }
         return response.json();
     }).then(response => {  
         let listOfNf=[];
         listOfNf=response.items;

       listOfNf.forEach(element => {

        sessionStorage.setItem(element.eid,element.uid);
          
       });
 });

        })
    }


    render() {
        return (
        
            <>
                <nav className="navbar navbar-expand-lg fixed-top navbar-dark bg-pink" id="mainheader">
                    <div className="container">
                        <LogoComponent imagePath="/images/logo.png" />

                        <button className="navbar-toggler p-0 border-0" type="button" data-toggle="offcanvas">
                            <span className="navbar-toggler-icon" />
                        </button>

                        <div className="navbar-collapse offcanvas-collapse" id="navbarsExampleDefault">
                            <SearchComponent searchText="What are you looking for" />
                            <MyAccountComponent />
                            <CartComponent />
                            <NotificationComponent />
                        </div>
                    </div>
                </nav>
                <MenuComponent />
                <StickyiconComponent />

                <section className="myaccount">
                    <div className="container">
                        <div className="row">
                            <div className="col-xl-3 col-lg-4 col-md-12">
                            <div className="accordion">
                                    <h3 className="text-white gothamMedium">My Dashboard</h3>
                                    <div className="card mb-3">
                                        <div className="card-header collapsed" data-toggle="collapse" data-target="#dashboardd">
                                            <a href="javascript:void(0);" className="card-title"> Dashboard <i className="fas fa-chevron-down" /></a>
                                        </div>
                                        <div id="dashboardd" className="card-body collapse">
                                            <ul className="nav nav-tabs flex-column" role="tablist">
                                                <li className="nav-item"><a className="nav-link" data-toggle="tab" href="#dashboard">Dashboard</a></li>
                                            </ul>
                                        </div>
                                        <div className="card-header" data-toggle="collapse" data-target="#privatecloud" aria-expanded="false">
                                            <a href="javascript:void(0);" className="card-title"> Private Cloud <i className="fas fa-chevron-down" /></a>
                                        </div>
                                        <div id="privatecloud" className="card-body collapse show">
                                            <ul className="nav nav-tabs flex-column" role="tablist">
                                                <li className="nav-item"><a className="nav-link active" data-toggle="tab" href="#private-cloud" onClick={this.onGetNfId}>Private Cloud</a></li>
                                            </ul>
                                        </div>
                                        <div className="card-header collapsed" data-toggle="collapse" data-target="#alarms">
                                            <a className="card-title"> Alarms <i className="fas fa-chevron-down" /></a>
                                        </div>
                                        <div id="alarms" className="card-body collapse">
                                            <ul className="nav nav-tabs flex-column" role="tablist">
                                                <li className="nav-item"><a className="nav-link" data-toggle="tab" href="#alarm">Alarm</a></li>
                                                <li className="nav-item"><a className="nav-link" data-toggle="tab" href="#insufficient">Insufficient</a></li>
                                                <li className="nav-item"><a className="nav-link" data-toggle="tab" href="#ok">Ok</a></li>
                                                <li className="nav-item"><a className="nav-link" data-toggle="tab" href="#billing">Billing</a></li>
                                            </ul>
                                        </div>
                                        <div className="card-header collapsed" data-toggle="collapse" data-target="#Logs">
                                            <a className="card-title"> Logs <i className="fas fa-chevron-down" /></a>
                                        </div>
                                        <div id="Logs" className="card-body collapse">
                                            <ul className="nav nav-tabs flex-column" role="tablist">
                                                <li className="nav-item"><a className="nav-link" data-toggle="tab" href="#log_groups">Log groups</a></li>
                                                <li className="nav-item"><a className="nav-link" data-toggle="tab" href="#insights">Insights</a></li>
                                            </ul>
                                        </div>
                                        <div className="card-header collapsed" data-toggle="collapse" data-target="#metricss">
                                            <a className="card-title"> Metrics <i className="fas fa-chevron-down" /></a>
                                        </div>
                                        <div id="metricss" className="card-body collapse">
                                            <ul className="nav nav-tabs flex-column" role="tablist">
                                                <li className="nav-item"><a className="nav-link" data-toggle="tab" href="#metrics">Metrics</a></li>
                                            </ul>
                                        </div>
                                        <div className="card-header collapsed" data-toggle="collapse" data-target="#events">
                                            <a className="card-title"> Events <i className="fas fa-chevron-down" /></a>
                                        </div>
                                        <div id="events" className="card-body collapse">
                                            <ul className="nav nav-tabs flex-column" role="tablist">
                                                <li className="nav-item"><a className="nav-link" data-toggle="tab" href="#rules">Rules</a></li>
                                                <li className="nav-item"><a className="nav-link" data-toggle="tab" href="#event_buses">Event Buses</a></li>
                                            </ul>
                                        </div>
                                        <div className="card-header collapsed" data-toggle="collapse" data-target="#servicelens">
                                            <a className="card-title"> ServiceLens <i className="fas fa-chevron-down" /></a>
                                        </div>
                                        <div id="servicelens" className="card-body collapse">
                                            <ul className="nav nav-tabs flex-column" role="tablist">
                                                <li className="nav-item"><a className="nav-link" data-toggle="tab" href="#servicemap">Service Map</a></li>
                                                <li className="nav-item"><a className="nav-link" data-toggle="tab" href="#traces">Traces</a></li>
                                            </ul>
                                        </div>
                                        <div className="card-header collapsed" data-toggle="collapse" data-target="#container_insights">
                                            <a className="card-title"> Container Insights <i className="fas fa-chevron-down" /></a>
                                        </div>
                                        <div id="container_insights" className="card-body collapse">
                                            <ul className="nav nav-tabs flex-column" role="tablist">
                                                <li className="nav-item"><a className="nav-link" data-toggle="tab" href="#resources">Resources</a></li>
                                                <li className="nav-item"><a className="nav-link" data-toggle="tab" href="#performancemonitoring">Performance Monitoring</a></li>
                                            </ul>
                                        </div>
                                        <div className="card-header collapsed" data-toggle="collapse" data-target="#lambda_insights">
                                            <a className="card-title"> Lambda Insights <i className="fas fa-chevron-down" /></a>
                                        </div>
                                        <div id="lambda_insights" className="card-body collapse">
                                            <ul className="nav nav-tabs flex-column" role="tablist">
                                                <li className="nav-item"><a className="nav-link" data-toggle="tab" href="#multi_function">Multi-function</a></li>
                                                <li className="nav-item"><a className="nav-link" data-toggle="tab" href="#single_function">Single-function</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-xl-9 col-lg-8 col-md-12">
                                <div className="tab-content" id="v-pills-tabContent">
                                    <div className="tab-pane fade" id="dashboard" role="tabpanel">
                                        <h3 className="text-pink gothamMedium">Dashboard</h3>
                                        <nav className="navbar navbar-expand-lg navbar-light bg-light">
                                            <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                                                <span className="navbar-toggler-icon" />
                                            </button>
                                            <div className="collapse navbar-collapse ml-auto" id="navbarNavDropdown">
                                                <ul className="navbar-nav ml-auto">
                                                    <li className="nav-item active">
                                                        <a className="nav-link" href="#">1h <span className="sr-only">(current)</span></a>
                                                    </li>
                                                    <li className="nav-item">
                                                        <a className="nav-link" href="#">3h</a>
                                                    </li>
                                                    <li className="nav-item">
                                                        <a className="nav-link" href="#">12h</a>
                                                    </li>
                                                    <li className="nav-item">
                                                        <a className="nav-link" href="#">1d</a>
                                                    </li>
                                                    <li className="nav-item">
                                                        <a className="nav-link" href="#">3d</a>
                                                    </li>
                                                    <li className="nav-item">
                                                        <a className="nav-link" href="#">1w</a>
                                                    </li>
                                                    <li className="nav-item dropdown btn-group">
                                                        <button type="button" className="btn btn-secondary">
                                                            <i className="fas fa-sync-alt" />
                                                        </button>
                                                        <button type="button" className="btn btn-secondary dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                            <span className="sr-only">Toggle Dropdown</span>
                                                        </button>
                                                        <div className="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                                                            <a className="dropdown-item" href="#">
                                                                <label className="form-check-label pink mb-0">
                                                                    <input className="form-check-input" defaultChecked type="checkbox" />
                                                                    <span className="checkmark" />
                                Auto Refresh
                              </label>
                                                            </a>
                                                            <div className="dropdown-divider" />
                                                            <h5 className="dropdown-header">Refresh interval</h5>
                                                            <a className="dropdown-item" href="#">
                                                                <label className="lblRdb text-body">10 Seconds
                                <input type="radio" name="radio" />
                                                                    <span className="checkmark" />
                                                                </label>
                                                            </a>
                                                            <a className="dropdown-item" href="#">
                                                                <label className="lblRdb text-body">1 Minute
                                <input type="radio" defaultChecked="checked" name="radio" />
                                                                    <span className="checkmark" />
                                                                </label>
                                                            </a>
                                                            <a className="dropdown-item" href="#">
                                                                <label className="lblRdb text-body">2 Minutes
                                <input type="radio" name="radio" />
                                                                    <span className="checkmark" />
                                                                </label>
                                                            </a>
                                                            <a className="dropdown-item" href="#">
                                                                <label className="lblRdb text-body">5 Minutes
                                <input type="radio" name="radio" />
                                                                    <span className="checkmark" />
                                                                </label>
                                                            </a>
                                                            <a className="dropdown-item" href="#">
                                                                <label className="lblRdb text-body">15 Minutes
                                <input type="radio" name="radio" />
                                                                    <span className="checkmark" />
                                                                </label>
                                                            </a>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </nav>
                                        <div className="row">
                                            <div className="col-md-12">
                                                <ShowcaseLayout onLayoutChange={this.onLayoutChange} />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="tab-pane fade active show" id="private-cloud" role="tabpanel">
                                        <h3 className="text-pink gothamMedium">Private Cloud</h3>
                                        <div id="accordion-pc">
                                            <div className="card">
                                                <div className="card-header" id="headingOne" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                    <i className="fas fas-3 fa-chevron-down visibility-hidden" />
                                                    <div className="card-header-title">
                                                        <i className="fas fa-cube mx-3" />
                                                        <ul>
                                                            <li>
                                                                <span>amazing_pascal <a href="#" className="text-pink ml-3">docker/getting-started</a></span>
                                                                <small>EXITED (0)</small>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div className="card-header-righticon">
                                                        <ul>
                                                            <li>
                                                                <a href="#" target="_blank" onClick={this.onBrowser}>
                                                                    <i className="fas fa-external-link-alt" title="Open in Browser" />
                                                                </a>
                                                            </li>
                                                            <li><a href="viewnginxplusdetails">
                                                                <i className="fas fa-cogs" title="Settings" />
                                                                </a>
                                                            </li>
                                                            <li className="start"><a href="#" onClick={this.onStart}>
                                                                <i className="fas fa-play text-pink" title="Start" /></a>
                                                            </li>
                                                            <li className="stop "><a href="#" onClick={this.onRestart}>
                                                                <i className="fas fa-redo-alt" title="Restart" /></a>
                                                            </li>
                                                            <li><a href="#" onClick={this.onDelete}>
                                                                <i className="fas fa-trash-alt text-pink" title="Delete" /></a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                                

                                                      <div className="card">
                                                <div className="card-header collapsed" id="headingTwo" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                                    <i className="fas fas-3 fa-chevron-down" />
                                                    <div className="card-header-title">
                                                        <i className="fas fa-cubes mx-3 text-pink" />
                                                        <ul>
                                                            <li>
                                                                <span>Robin_Cluster</span>
                                                                <small>ONLINE</small>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div className="card-header-righticon">
                                                        <ul className='d-none'>
                                                            <li className="start"><a href="#" onClick={this.onStart}>
                                                                <i className="fas fa-play text-pink" title="Start" /></a>
                                                            </li>
                                                            <li className="stop "><a href="#" onClick={this.onStop}>
                                                                <i className="fas fa-stop" title="Stop" /></a>
                                                            </li>
                                                            <li><a href="#" onClick={this.onDelete}>
                                                                <i className="fas fa-trash-alt text-pink" title="Delete" /></a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div id="collapseTwo" className="collapse" aria-labelledby="headingTwo" data-parent="#accordion-pc">
                                                    <div className="card-body">
                                                        <table className="table table-hover">
                                                            <tbody>
                                                            {this.state.listApp.length > 0 ?
                                                this.state.listApp.map((data, index) => (
                                                    <tr id={data.name + '-' + index} className={data.status == "ONLINE" ? "running" : ""}>
                                                                    <td className="icon">
                                                                        <i className="fas fa-cube ml-3" />
                                                                    </td>
                                                                    <td>
                                                                        <ul>
                                                                        <li>
                                                <b>{data.name}<a href="#" className="ml-3">{data.name}</a></b>
                                                <small className="d-block">{data.status} </small>
                                               
                                                                            </li>
                                                                        </ul>
                                                                    </td>
                                                                    <td className="td-status">
                                                                                <div class="badge badge-secondary bg-pink px-2 py-1" style={{display: "none"}}>
                                                                                    <i className="fa fa-spinner fa-spin"></i>
                                                                                    <b className="ml-2">START</b>
                                                                                    </div>
                                                                    </td>
                                                                    <td className="td-icons">
                                                                        <ul>
                                                                        <li>
                                                                                <a href="#" target="_blank" id="browserId" onClick={(e) => this.onBrowser(e,data.name)}>
                                                                                    <i className="fas fa-external-link-alt" title="Open in Browser" /></a>
                                                                            </li>
                                                                            <li><a href="/modifyResource" onClick={(e) => this.onSetting(e,data.name)}>
                                                                                <i className="fas fa-cogs" title="Settings" /></a>
                                                                            </li>
                                                                            <li className="start"><a href="#"  id="application_name" onClick={(e) => this.onStart(e,data.name,index)}>
                                                                                <i className="fas fa-play text-pink" title="Start" /></a>
                                                                            </li>
                                                                            <li className="stop "><a href="#" onClick={(e) => this.onStop(e,data.name,index)}>
                                                                                <i className="fas fa-stop" title="Stop" /></a>
                                                                            </li>
                                                                            <li><a href="#" onClick={(e) => this.onRestart(e,data.name,index)}>
                                                                                <i className="fas fa-redo-alt" title="Restart" /></a>
                                                                            </li>
                                                                            <li><a href="#" onClick={(e) => this.onDelete(e,data.name,index)}>
                                                                                <i className="fas fa-trash-alt text-pink" title="Delete" /></a>
                                                                            </li>
                                                                        </ul>
                                                                    </td>
                                                                </tr>
                                                                  ))
                                                                  : ""}
                                                                </tbody>
                                                                </table>
                                                                </div>
                                                      </div>
                                                      </div>

                                            <div className="card">
                                                <div className="card-header collapsed" id="headingThree" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                                    <i className="fas fas-3 fa-chevron-down" />
                                                    <div className="card-header-title">
                                                        <i className="fas fa-cubes mx-3" />
                                                        <ul>
                                                            <li>
                                                                <span>docker-compose</span>
                                                                <small>EXITED (UNDEFINED)</small>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div className="card-header-righticon">
                                                        <ul>
                                                            <li className="start"><a href="#">
                                                                <i className="fas fa-play text-pink" title="Start" onClick={this.onStart} /></a>
                                                            </li>
                                                            <li className="stop "><a href="#" onClick={this.onStop}>
                                                                <i className="fas fa-stop" title="Stop" /></a>
                                                            </li>
                                                            <li><a href="#" onClick={this.onDelete}>
                                                                <i className="fas fa-trash-alt text-pink" title="Delete" /></a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div id="collapseThree" className="collapse" aria-labelledby="headingThree" data-parent="#accordion-pc">
                                                    <div className="card-body">
                                                        <table className="table table-hover">
                                                            <tbody>
                                                                <tr>
                                                                    <td className="icon">
                                                                        <i className="fas fa-cube ml-3" />
                                                                    </td>
                                                                    <td>
                                                                        <ul>
                                                                            <li>
                                                                                <b>activiti-cloud-query<a href="#" className="ml-3">activiti/activiti-cloud-query:7.1.0.MS</a></b>
                                                                                <small className="d-block">EXITED (143)</small>
                                                                            </li>
                                                                        </ul>
                                                                    </td>
                                                                  
                                                                    <td className="td-icons">
                                                                        <ul>
                                                                            <li>
                                                                                <a href="#" target="_blank" onClick={this.onBrowser}>
                                                                                    <i className="fas fa-external-link-alt" title="Open in Browser" /></a>
                                                                            </li>
                                                                            <li><a href="viewnginxplusdetails" onClick={this.onSetting}>
                                                                                <i className="fas fa-cogs" title="Settings" /></a>
                                                                            </li>
                                                                            <li className="start"><a href="#" onClick={this.onStart}>
                                                                                <i className="fas fa-play text-pink" title="Start" /></a>
                                                                            </li>
                                                                            <li className="stop "><a href="#" onClick={this.onStop}>
                                                                                <i className="fas fa-stop" title="Stop" /></a>
                                                                            </li>
                                                                            <li><a href="#" onClick={this.onRestart}>
                                                                                <i className="fas fa-redo-alt" title="Restart" /></a>
                                                                            </li>
                                                                            <li><a href="#" onClick={this.onDelete}>
                                                                                <i className="fas fa-trash-alt text-pink" title="Delete" /></a>
                                                                            </li>
                                                                        </ul>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td className="icon">
                                                                        <i className="fas fa-cube ml-3" />
                                                                    </td>
                                                                    <td>
                                                                        <ul>
                                                                            <li>
                                                                                <b>example-cloud-connector<a href="#" className="ml-3">activiti/example-cloud-connector:7.1.0.MS</a></b>
                                                                                <small className="d-block">EXITED (143)</small>
                                                                            </li>
                                                                        </ul>
                                                                    </td>
                                                                    <td className="td-icons">
                                                                        <ul>
                                                                            <li>
                                                                                <a href="#" target="_blank">
                                                                                    <i className="fas fa-external-link-alt" title="Open in Browser" /></a>
                                                                            </li>
                                                                            <li><a href="viewnginxplusdetails">
                                                                                <i className="fas fa-cogs" title="Settings" /></a>
                                                                            </li>
                                                                            <li className="start"><a href="#">
                                                                                <i className="fas fa-play text-pink" title="Start" /></a>
                                                                            </li>
                                                                            <li className="stop "><a href="#">
                                                                                <i className="fas fa-stop text-pink" title="Stop" /></a>
                                                                            </li>
                                                                            <li><a href="#">
                                                                                <i className="fas fa-redo-alt" title="Restart" /></a>
                                                                            </li>
                                                                            <li><a href="#">
                                                                                <i className="fas fa-trash-alt text-pink" title="Delete" /></a>
                                                                            </li>
                                                                        </ul>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td className="icon">
                                                                        <i className="fas fa-cube ml-3" />
                                                                    </td>
                                                                    <td>
                                                                        <ul>
                                                                            <li>
                                                                                <b>example-runtime-bundle<a href="#" className="ml-3">activiti/example-runtime-bundle:7.1.0.MS</a></b>
                                                                                <small className="d-block">EXITED (137)</small>
                                                                            </li>
                                                                        </ul>
                                                                    </td>
                                                                    <td className="td-icons">
                                                                        <ul>
                                                                            <li>
                                                                                <a href="#" target="_blank">
                                                                                    <i className="fas fa-external-link-alt" title="Open in Browser" /></a>
                                                                            </li>
                                                                            <li><a href="viewnginxplusdetails">
                                                                                <i className="fas fa-cogs" title="Settings" /></a>
                                                                            </li>
                                                                            <li className="start"><a href="#">
                                                                                <i className="fas fa-play text-pink" title="Start" /></a>
                                                                            </li>
                                                                            <li className="stop "><a href="#">
                                                                                <i className="fas fa-stop text-pink" title="Stop" /></a>
                                                                            </li>
                                                                            <li><a href="#">
                                                                                <i className="fas fa-redo-alt" title="Restart" /></a>
                                                                            </li>
                                                                            <li><a href="#">
                                                                                <i className="fas fa-trash-alt text-pink" title="Delete" /></a>
                                                                            </li>
                                                                        </ul>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td className="icon">
                                                                        <i className="fas fa-cube ml-3" />
                                                                    </td>
                                                                    <td>
                                                                        <ul>
                                                                            <li>
                                                                                <b>activiti-cloud-modeling<a href="#" className="ml-3">activiti/activiti-modeling-app:7.1.0.MS</a></b>
                                                                                <small className="d-block">EXITED (137)</small>
                                                                            </li>
                                                                        </ul>
                                                                    </td>
                                                                    <td className="td-icons">
                                                                        <ul>
                                                                            <li>
                                                                                <a href="#"  target="_blank">
                                                                                    <i className="fas fa-external-link-alt" title="Open in Browser" /></a>
                                                                            </li>
                                                                            <li><a href="viewnginxplusdetails">
                                                                                <i className="fas fa-cogs" title="Settings" /></a>
                                                                            </li>
                                                                            <li className="start"><a href="#">
                                                                                <i className="fas fa-play text-pink" title="Start" /></a>
                                                                            </li>
                                                                            <li className="stop"><a href="#">
                                                                                <i className="fas fa-stop text-pink" title="Stop" /></a>
                                                                            </li>
                                                                            <li><a href="#">
                                                                                <i className="fas fa-redo-alt" title="Restart" /></a>
                                                                            </li>
                                                                            <li><a href="#">
                                                                                <i className="fas fa-trash-alt text-pink" title="Delete" /></a>
                                                                            </li>
                                                                        </ul>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td className="icon">
                                                                        <i className="fas fa-cube ml-3" />
                                                                    </td>
                                                                    <td>
                                                                        <ul>
                                                                            <li>
                                                                                <b>activiti-cloud-modeling-backend<a href="#" className="ml-3">activiti/cloud-modeling:7.1.0.MS</a></b>
                                                                                <small className="d-block">EXITED (143)</small>
                                                                            </li>
                                                                        </ul>
                                                                    </td>
                                                                    <td className="td-icons">
                                                                        <ul>
                                                                            <li>
                                                                                <a href="#" target="_blank">
                                                                                    <i className="fas fa-external-link-alt" title="Open in Browser" /></a>
                                                                            </li>
                                                                            <li><a href="viewnginxplusdetails">
                                                                                <i className="fas fa-cogs" title="Settings" /></a>
                                                                            </li>
                                                                            <li className="start"><a href="#">
                                                                                <i className="fas fa-play text-pink" title="Start" /></a>
                                                                            </li>
                                                                            <li className="stop"><a href="#">
                                                                                <i className="fas fa-stop text-pink" title="Stop" /></a>
                                                                            </li>
                                                                            <li><a href="#">
                                                                                <i className="fas fa-redo-alt" title="Restart" /></a>
                                                                            </li>
                                                                            <li><a href="#">
                                                                                <i className="fas fa-trash-alt text-pink" title="Delete" /></a>
                                                                            </li>
                                                                        </ul>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td className="icon">
                                                                        <i className="fas fa-cube ml-3" />
                                                                    </td>
                                                                    <td>
                                                                        <ul>
                                                                            <li>
                                                                                <b>docker-compose_activiti-postgres_1<a href="#" className="ml-3">postgres</a></b>
                                                                                <small className="d-block">EXITED (0) &nbsp;&nbsp; PORT:5432</small>
                                                                            </li>
                                                                        </ul>
                                                                    </td>
                                                                    <td className="td-icons">
                                                                        <ul>
                                                                            <li>
                                                                                <a href="#" target="_blank">
                                                                                    <i className="fas fa-external-link-alt" title="Open in Browser" /></a>
                                                                            </li>
                                                                            <li><a href="viewnginxplusdetails">
                                                                                <i className="fas fa-cogs" title="Settings" /></a>
                                                                            </li>
                                                                            <li className="start"><a href="#">
                                                                                <i className="fas fa-play text-pink" title="Start" /></a>
                                                                            </li>
                                                                            <li className="stop"><a href="#">
                                                                                <i className="fas fa-stop text-pink" title="Stop" /></a>
                                                                            </li>
                                                                            <li><a href="#">
                                                                                <i className="fas fa-redo-alt" title="Restart" /></a>
                                                                            </li>
                                                                            <li><a href="#">
                                                                                <i className="fas fa-trash-alt text-pink" title="Delete" /></a>
                                                                            </li>
                                                                        </ul>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="tab-pane fade" id="alarm" role="tabpanel">
                                        <h3 className="text-pink gothamMedium">Alarm</h3>
                                    </div>
                                    <div className="tab-pane fade" id="insufficient" role="tabpanel">
                                        <h3 className="text-pink gothamMedium">Insufficient</h3>
                                    </div>
                                    <div className="tab-pane fade" id="ok" role="tabpanel">
                                        <h3 className="text-pink gothamMedium">Ok</h3>
                                    </div>
                                    <div className="tab-pane fade" id="billing" role="tabpanel">
                                        <h3 className="text-pink gothamMedium">Billing</h3>
                                    </div>
                                    <div className="tab-pane fade" id="log_groups" role="tabpanel">
                                        <h3 className="text-pink gothamMedium">Log Groups</h3>
                                    </div>
                                    <div className="tab-pane fade" id="insights" role="tabpanel">
                                        <h3 className="text-pink gothamMedium">Insights</h3>
                                    </div>
                                    <div className="tab-pane fade" id="metrics" role="tabpanel">
                                        <h3 className="text-pink gothamMedium">Metrics</h3>
                                    </div>
                                    <div className="tab-pane fade" id="rules" role="tabpanel">
                                        <h3 className="text-pink gothamMedium">Rules</h3>
                                    </div>
                                    <div className="tab-pane fade" id="event_buses" role="tabpanel">
                                        <h3 className="text-pink gothamMedium">Event Buses</h3>
                                    </div>
                                    <div className="tab-pane fade" id="servicemap" role="tabpanel">
                                        <h3 className="text-pink gothamMedium">Service Map</h3>
                                    </div>
                                    <div className="tab-pane fade" id="traces" role="tabpanel">
                                        <h3 className="text-pink gothamMedium">Traces</h3>
                                    </div>
                                    <div className="tab-pane fade" id="resources" role="tabpanel">
                                        <h3 className="text-pink gothamMedium">Resources</h3>
                                    </div>
                                    <div className="tab-pane fade" id="performancemonitoring" role="tabpanel">
                                        <h3 className="text-pink gothamMedium">Performance Monitoring</h3>
                                    </div>
                                    <div className="tab-pane fade" id="multi_function" role="tabpanel">
                                        <h3 className="text-pink gothamMedium">Multi-function</h3>
                                    </div>
                                    <div className="tab-pane fade" id="single_function" role="tabpanel">
                                        <h3 className="text-pink gothamMedium">Single-function</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <FooterComponent />
            </>

        );
    }
}

export default MyDashboard;