import React from 'react';

var CartComponent = function() {



    return (
   
        <ul className="navbar-nav">
              <li className="nav-item dropdown drop-cart d-none d-lg-block">
                        <a href="/cartDetail" className="nav-link dropdown-toggle" id="cart">
                            <i className="fa fa-shopping-cart"></i>
                            <span>0</span>
                        </a>
                        <div className="dropdown-menu dropdown-menu-right" aria-labelledby="cart">
                            <div className="row">
                                <div className="col-12">
                                    <div className="d-flex align-items-center m-3 btn-goto">
                                        <a href="/emptycart" className="btn btn-pink withoutRadiusBorder w-100">GO TO CART</a>
                                        <a href="#" className="btn btn-success withoutRadiusBorder w-100 d-none">CHECKOUT</a>
                                    </div>
                                </div>
                                <div className="col-12">
                                    <h6 className="minicart-header">Your Shopping Basket [ <span>0</span> ]</h6>
                                </div>
                                <div className="col-12">
                                    <div className="scroll-height ">
                                    <div className="card" stl-id="4241349">
                                            <div className="row no-gutters">
                                                <div className="cardimg">
                                                    <img src="./images/office-365-enterprise-e1.png" className="card-img" alt="Office 365 Enterprise E1"/>
                                                </div>
                                                <div className="card-body flex-column">
                                                    <h5 className="card-title w-100">Office 365 Enterprise E1</h5>
                                                    <div className="quantityGroup">
                                                        <h6 className="gothamMedium mb-0">Qty :</h6>
                                                        <button type="button" className="round-btn sub" title="If u want less quantity">-</button>
                                                        <input className="quantityTxt quantity " name="quantity[]" type="text" defaultValue="1" maxLength="4"/>
                                                        <button type="button" className="round-btn add" title="If u want more quantity">+</button>
                                                    </div>
                                                    <i className="fa fa-trash text-danger"></i>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="card" stl-id="100772575">
                                            <div className="row no-gutters">
                                                <div className="cardimg">
                                                    <img src="./images/brand-ADO.gif" className="card-img" alt="Adobe Coldfusion Standard 2016 All Platforms"/>
                                                </div>
                                                <div className="card-body flex-column">
                                                    <h5 className="card-title w-100">Adobe Coldfusion Standard 2016 All Platforms</h5>
                                                    <div className="quantityGroup">
                                                        <h6 className="gothamMedium mb-0">Qty :</h6>
                                                        <button type="button" className="round-btn sub" title="If u want less quantity">-</button>
                                                        <input className="quantityTxt quantity " name="quantity[]" type="text" defaultValue="1" maxLength="4"/>
                                                        <button type="button" className="round-btn add" title="If u want more quantity">+</button>
                                                    </div>
                                                    <i className="fa fa-trash text-danger"></i>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="card" stl-id="4465825">
                                            <div className="row no-gutters">
                                                <div className="cardimg">
                                                    <img src="./images/laptop.jpeg" className="card-img" alt="Dell Precision 3551 i7 32/512GB Mob. WS"/>
                                                </div>
                                                <div className="card-body flex-column">
                                                    <h5 className="card-title w-100">Dell Precision 3551 i7 32/512GB Mob. WS</h5>
                                                    <div className="quantityGroup">
                                                        <h6 className="gothamMedium mb-0">Qty :</h6>
                                                        <button type="button" className="round-btn sub" title="If u want less quantity">-</button>
                                                        <input className="quantityTxt quantity " name="quantity[]" type="text" defaultValue="1" maxLength="4"/>
                                                        <button type="button" className="round-btn add" title="If u want more quantity">+</button>
                                                    </div>
                                                    <i className="fa fa-trash text-danger"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
        </ul>
      );
};

export default CartComponent;


