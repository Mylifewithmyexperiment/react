import React from "react";
import { connect } from "react-redux";

class NotificationComponent extends React.Component {
  constructor(props) {
    super();

    this.state = {
      notification_data: [],
    };
  }

  render() {
    let notification_number = 0;
    if (this.props.data.length > 0) {
      notification_number = Number(this.props.data.length);
    } else {
      notification_number = 0;
    }
    return (
      <ul className="navbar-nav">
        <li class="nav-item dropdown no-arrow mx-1">
          <a
            class="nav-link dropdown-toggle"
            href="#"
            id="alertsDropdown"
            role="button"
            data-toggle="dropdown"
            aria-haspopup="true"
            aria-expanded="false"
          >
            <i class="fas fa-bell fa-fw"></i>

            <span class="badge badge-danger badge-counter">
              {notification_number}
            </span>
          </a>

          <div
            class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
            aria-labelledby="alertsDropdown"
          >
            <a class="dropdown-item d-flex align-items-center" href="#">
              <div class="mr-3">
                {/* <div class="icon-circle bg-primary">
                  <i class="fas fa-file-alt text-white"></i>
                </div> */}
              </div>
              <div>
                {/* <div class="small text-gray-500"> Nginx status</div> */}
                <span class="font-weight-bold">
                  <ul>
                    {this.props.data.length > 0
                      ? this.props.data.map((item, i) => {
                          return <li> {item} </li>;
                        })
                      : "No Notifications available"}
                  </ul>
                </span>
              </div>
            </a>

            {/* <a class="dropdown-item d-flex align-items-center" href="#">
              <div class="mr-3">
                <div class="icon-circle bg-success">
                  <i class="fas fa-donate text-white"></i>
                </div>
              </div>
              <div>
                <div class="small text-gray-500">December 7, 2019</div>
                $290.29 has been deposited into your account!
              </div>
            </a>

            <a class="dropdown-item d-flex align-items-center" href="#">
              <div class="mr-3">
                <div class="icon-circle bg-warning">
                  <i class="fas fa-exclamation-triangle text-white"></i>
                </div>
              </div>
              <div>
                <div class="small text-gray-500">December 2, 2019</div>
                Spending Alert: We've noticed unusually high spending for your
                account.
              </div>
            </a> */}
          </div>
        </li>
      </ul>
    );
  }

  // notification_details() {
  //   const notification_detail  = this.state.notification_data;
  //   notification_detail.push(this.props.data.Notification_message);
  //   this.setState({
  //     notification_data : notification_detail
  //   })
  //   }
  //   notification_detail();
}

const mapStateToProps = (state) => ({
  data: state.sharableData.notification_details,
});
export default connect(mapStateToProps)(NotificationComponent);
