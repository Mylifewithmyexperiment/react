import React from 'react';
import Productdata from './Data/Productdetail.json';
import Slider from "react-slick";

class ServiceComponent extends React.Component {

  constructor(props) {
    super(props);

    this.state = {
      cardDetail: Productdata
    };
  }

  render() {
    const settings = {
      dots: true,
      infinite: true,
      speed: 500,
      slidesToShow: 6,
      slidesToScroll: 1,
      responsive: [{
        breakpoint: 1921,
        settings: {
          slidesToShow: 6,
          slidesToScroll: 1,
        }
      },
      {
        breakpoint: 1641,
        settings: {
          slidesToShow: 5,
          slidesToScroll: 1,
        }
      },
      {
        breakpoint: 1441,
        settings: {
          slidesToShow: 4,
          slidesToScroll: 1,
        }
      }, {
        breakpoint: 1200,
        settings: {
          slidesToShow: 4,
          slidesToScroll: 1,
        }
      },
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
        }
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        }
      },
      {
        breakpoint: 576,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        }
      }
        // You can unslick at a given breakpoint now by adding:
        // settings: "unslick"
        // instead of a settings object
      ]
    };
    return (
      <div>
        <section className="product_section">
          <div className="container">
            <div className="row">
              <div className="col-md-12">
                <Slider className="product_slider" {...settings}>
                  {this.state.cardDetail.map(function (slide) {
                    return (
                      <div key={slide} >

                        <div className="card">
                          <div className="card-body" style={{ backgroundImage: `url(${slide.backgroundImage})` }}>
                            <div className="mt-auto">
                              <h5 className="card-title">{slide.text}</h5>
                              <p className="card-text">{slide.description}</p>

                              <a href="#" className="btn btn-primary btn-pink">Know more</a>
                            </div>
                          </div>
                        </div>

                      </div>
                    );
                  })}
                </Slider>
              </div>
            </div>
          </div>
        </section>
      </div>
    );
  }

}

export default ServiceComponent;



/*const styles1= {
    backgroundImage: 'url(/images/network_slicing.png)',
  }

const styles2 = {
    backgroundImage: 'url(/images/cloud_applications.png)',
    backgroundPosition: 'center right -60px',
  }

  const styles3 = {
    backgroundImage: 'url(/images/Enabler_services.png)'
  }

  const styles4= {
    backgroundImage: ' url(/images/Rf_planning.png)',
    backgroundPosition: 'right -100px center',
  }

  const styles5= {
    backgroundImage: ' url(/images/network_slicing.png)'
  }

  const styles6= {
    backgroundImage: ' url(/images/cloud_applications.png)',
    backgroundPosition: 'center right -60px',
  }



  const styles7= {
    backgroundImage: ' url(/images/Enabler_services.png)'
  }

  const styles8= {
    backgroundImage: ' url(/images/Rf_planning.png)',
    backgroundPosition: 'right -100px center',
  }*/
