import React from 'react';
import HomePage from  './HomePage';
import { BrowserRouter as Router, Route, Link, Switch } from 'react-router-dom'; 
import CheckoutStep from './CheckoutSteps'
import VRanDetailPageComponent from './VRanDetailPageComponent';
import Office365CartDetailComponent from './Office365CartDetailComponent';
import CartDetailsComponent from './CartDetailsComponent';
import QuoteComponent from './QuoteComponent';
import Office365DetailComponent from './Office365DetailComponent';
import MyAccountDetailPageComponent from './MyAccounDetailPageComponent';
import SubmitQuoteComponent from './SubmitQuoteComponent';
import EmptyCartComponent from './EmptyCartComponent';
import Office365ImageComponent from './Office365ImageComponent';
import PrivateCloudServiceComponent from './PrivateCloudServiceComponent';
import BrandDetailComponent from './BrandDetailComponent';
import CatlogDetailsComponent from './CatlogDetailsComponent';
import LoginComponent from './LoginComponent';
import NgInxPlusComponent from './NgInxPlusComponent';
import CartnginxComponent from './CartnginxComponent';
import CartMongodbComponent from './CartMongodbComponent';
import EmptyCartDetailComponent from './EmptyCartDetailComponent';
import NginxCartdetailComponent from './NginxCartdetailComponent';
import RobinNginxPlusComponent from './RobinNginxPlusComponent';
import CheckoutRobinComponent from './CheckoutRobinComponent';
import MyDashboard from './MyDashboard';
import ShowcaseLayout from './ShowcaseLayout';
import ViewNgInxPlusComponent from './ViewNgInxPlusComponent'
import UpdateRobinApplication from './UpdateRobinApplication';
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as Actions from "./action";
import Test from './Test';

const mapDispatchToProps = (dispatch) => ({
  actions: bindActionCreators(Actions, dispatch),
});

function App() {
  return (
   
    <div >
       
    <Router>
           <Switch> 
              <Route exact path='/' component={HomePage}></Route> 
              <Route exact path='/product-detail' component={VRanDetailPageComponent}></Route> 
              <Route exact path='/checkout' component={CheckoutStep}></Route> 
              <Route exact path='/office365EnterpriceDetails' component={Office365CartDetailComponent}></Route> 
              <Route exact path='/cartDetail' component={CartDetailsComponent}></Route> 
              <Route exact path='/quoteDetail' component={QuoteComponent}></Route> 
              <Route exact path='/new' component={Office365DetailComponent}></Route> 
              <Route exact path='/myaccountdetailPage' component={MyAccountDetailPageComponent}></Route> 
              <Route exact path='/submitquote' component={SubmitQuoteComponent}></Route> 
              <Route exact path='/emptycart' component={EmptyCartComponent}></Route> 
              <Route exact path='/privatecloudservicedetail' component={PrivateCloudServiceComponent}></Route> 
              <Route exact path='/brandetail' component={BrandDetailComponent}></Route> 
              <Route exact path='/catlogDetails' component={CatlogDetailsComponent}></Route> 
              <Route exact path='/login' component={LoginComponent}></Route> 
              <Route exact path='/nginxplusdetails' component={NgInxPlusComponent}></Route> 
              <Route exact path='/cartnginxdetail' component={CartnginxComponent}></Route> 
              <Route exact path='/mongocartdetail' component={CartMongodbComponent}></Route>
              <Route exact path='/emptyCartDetailComponent' component={EmptyCartDetailComponent}></Route> 
              <Route exact path='/nginxCartdetailComponent' component={NginxCartdetailComponent}></Route>
              <Route exact path='/office365_details' component={Office365DetailComponent}></Route>
              <Route exact path='/office365_cartdetails' component={Office365CartDetailComponent}></Route>
              <Route exact path='/robinNginxdetails' component={RobinNginxPlusComponent}></Route>
              <Route exact path='/robincheckoutservice' component={CheckoutRobinComponent}></Route>
              <Route exact path='/mydashboard' component={MyDashboard}></Route>
              <Route exact path='/showcaselayout' component={ShowcaseLayout}></Route>
              <Route exact path ='/modifyResource' component={ViewNgInxPlusComponent}></Route>
              <Route exact path ='/updateRobinApplication' component={UpdateRobinApplication}></Route>
              <Route exact path ="/notificationComponent" component ={Notification}></Route>
              <Route exact path ="/test" component={Test}></Route>
            </Switch> 

    </Router>
    </div>

  );
}
export default connect (null, mapDispatchToProps)(App);