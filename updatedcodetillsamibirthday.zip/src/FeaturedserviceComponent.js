import React from 'react';
import FeaturedService from './Data/Featuredservice.json';
import Slider from "react-slick";

class FeaturedserviceComponent extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            featureServiceDetail: FeaturedService
        };
    }

    render() {
        const settings = {
            dots: false,
            infinite: true,
            slidesToShow: 7,
            responsive: [{
                breakpoint: 1921,
                settings: {
                    slidesToShow: 7,
                    slidesToScroll: 1,
                }
            },
            {
                breakpoint: 1641,
                settings: {
                    slidesToShow: 6,
                    slidesToScroll: 1,
                }
            },
            {
                breakpoint: 1441,
                settings: {
                    slidesToShow: 5,
                    slidesToScroll: 1,
                }
            },
            {
                breakpoint: 1200,
                settings: {
                    slidesToShow: 4,
                    slidesToScroll: 1,
                }
            },
            {
                breakpoint: 992,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                }
            },
            {
                breakpoint: 576,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                }
            }
                // You can unslick at a given breakpoint now by adding:
                // settings: "unslick"
                // instead of a settings object
            ]
        };
        return (
            <>
                <section className="featured_services">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12">
                                <h2 className="text-white"><strong className="text-pink">Featured</strong> Services</h2>

                                <Slider className="service_slider" {...settings}>
                                    {this.state.featureServiceDetail.map(function (slide) {
                                        return (
                                            <div key={slide} >
                                                <div className="card">
                                                    <div className="card-body">
                                                        <img src={slide.image} alt="Network Security" />
                                                        <h5 className="card-title">{slide.title}</h5>
                                                    </div>
                                                </div>
                                            </div>
                                        );
                                    })}
                                </Slider>
                            </div>
                        </div>
                    </div>
                </section>
            </>
        );
    }
}

export default FeaturedserviceComponent;