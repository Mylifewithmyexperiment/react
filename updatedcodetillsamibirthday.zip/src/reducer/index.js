import { combineReducers } from "redux";
import sharableData from "./sharableData"
 
const AddAllReducers =combineReducers({
    
    sharableData :sharableData
});


export default AddAllReducers;