import {
  CLUSTER_UID_DATA,
  DELETE_NOTIFICATION_QUANTITY,
  SEND_NOTIFICATION_DATA,
  SEND_PRODUCT_TO_CART, ADD_QUANTITY, 
  SUBS_QUANTITY, DELETE_QUANTITY
} from "../actionTypes";

const initialstate = {
  name: "",
  data: "",
  quantity: "0",
  logo :"",
  notification_details: {
    notification_quantity: 0,
  },
}; 


const sharableData = (state = initialstate, action) => {
  switch (action.type) {
    case CLUSTER_UID_DATA:
      return {
        ...state,
        details: action.params,
      };

    case SEND_NOTIFICATION_DATA:
      return {
        ...state,
        notification_details: action.params,
      };
    case DELETE_NOTIFICATION_QUANTITY:
      return {
        params: action.params,
      };

      case SEND_PRODUCT_TO_CART:
        return {
          ...state,
          cart_details : action.params,
          name: action.params.product_name,
          author:action.params.product_author,
          quantity:action.params.product_quantity,
          logo:action.params.product_logo,
        };
        case ADD_QUANTITY:
        return{
        ...state,
        quantity :action.params,
  
        };
        case SUBS_QUANTITY:
          return{
            ...state,
            quantity:action.params,
          };
          case  DELETE_QUANTITY:
            return{
              params :action.params
            }
  
      default:
        return state;
  }
};

export default sharableData;
