import {
  CLUSTER_UID_DATA,
  SEND_NOTIFICATION_DATA,
  DELETE_NOTIFICATION_QUANTITY,
  SEND_PRODUCT_TO_CART,
  ADD_QUANTITY,
  SUBS_QUANTITY,DELETE_QUANTITY
} from "../actionTypes";

const initialstate = {
  name: "",
  quantity: "0",
  logo: "",
  details: "",
  author: "",
};
// params: Number(++params),

export const onClusterSelect = (params) => {
  console.log(params);
  return {
    type: CLUSTER_UID_DATA,
    params,
  };
};

export const sendNotificationData = (params ) => {
  return {
    type: SEND_NOTIFICATION_DATA,
    params,
    // notificationMap
  };
};

export const deleteNotificationCount = (params) => {
  return {
    type: DELETE_NOTIFICATION_QUANTITY,
    params: initialstate,
  };
};

export const sendProductToCartAction = (params) => ({
  type: SEND_PRODUCT_TO_CART,
  params,
});

export const addQuantity = (params) => ({
  type: ADD_QUANTITY,
  params: Number(++params),
});

export const subsQuantity = (params) => ({
  type: SUBS_QUANTITY,
  params: Number(--params),
  
});

export const deleteProduct = (params)=>( {
type: DELETE_QUANTITY,
  details:null,
  name :"",
  author:"",
  quantity:"0",
  logo:"",
params:initialstate
});