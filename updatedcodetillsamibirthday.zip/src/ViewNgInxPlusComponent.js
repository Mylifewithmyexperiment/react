import React from 'react';
import LogoComponent from './LogoComponent'
import CartComponent from './CartComponent'
import SearchComponent from './SearchComponent'
import MyAccountComponent from './MyAccountComponent';
import MenuComponent from './MenuComponent';
import FooterComponent from './FootComponent';
import StickyiconComponent from './StickyiconComponent';
import $ from 'jquery';
import NotificationComponent from './NotificationComponent';

class ViewNgInxPlusComponent extends React.Component {
     constructor() {
        super();
        this.state = {
            TAG_NAME: "",
            namespace : "",
            clusterName: "",
        };
    }

    save_details() {
        let cpu = $("#vpc1").val();
        let ram = $("#gbram1").val();
        let disk = $("#gbdisk1").val();

        sessionStorage.setItem("cpu", cpu);
        sessionStorage.setItem("ram", ram);
        sessionStorage.setItem("disk", disk);
        sessionStorage.setItem("cluster", "Robin-Cluster");
    }

    appConfiguration() {
        let appValue =sessionStorage.getItem("selected-app");

        const loginData = {
            method: 'POST',
            headers: new Headers({
                'Content-Type': 'application/json'
            }),
            body: JSON.stringify(
                {
                    "username": "robin",
                    "password":"Robin@123",
                    "tenant":"Administrators"
                }
            )  
        };
    
        fetch('https://10.151.35.44:29442/api/v3/robin_server/login',loginData)
        .then(response => {
    
            if (!response.ok) {
            console.log("response is not correct ");
            }
    
            return response.json();
        }).then(response => {
    
            let authorization=response.token;

            fetch('https://10.151.35.44:29442/api/v6/robin_server/apps/'+appValue+'?info=true&details=vnodes', {

                method: 'GET',
                headers: new Headers({
                    'Authorization': authorization,
                    'Content-Type': 'application/json',
                })
                }).then(response => {

                if (!response.ok) {
                console.log(response);
                }

                return response.json();
                }).then(json => {


                this.setState({

                    name : json.ainstances[0].app,
                    url : json.appinfo.service_urls[0].url,
                    memory : json.mem,
                    storage : json.ainstances[0].storage[0].size,
                    cpu : json.ainstances[0].cpu_cores,
                    showConfig : true,
                    namespace : json.config.namespace
                })

                  this.state.memory > 0 ? $('#gbram1').val(Math.floor(this.state.memory/1024/1024/1024)) : $('#gbram1').val(0)
                
                this.state.storage > 0 ? $('#gbdisk1,#gbdisk').val(this.state.storage/1024/1024/1024) : $('#gbdisk1').val(0)
                $('#vpc1,#vpc').val(this.state.cpu);
                $('#deployed-namespace').val(this.state.namespace);
                $('#cluster-name').val(this.state.clusterName);
                // var existingPlan = $("#gbram").val();
                // alert(existingPlan);
                //this.state.existingEstimationCost = $("")
                this.estimatecost();
                // $(".catalog_details .summary .summary-body .existingCost span").text();
            });
        });
    }

    estimatecost() {
        var sumofestimatecost = 0;
        $(".catalog_details .tab-content .tab-pane .pricing_plan .plan_tbl .row").each(function () {
            if ($(this).hasClass("activCls")) {
                if ($(this).find("ul").hasClass("plan_price")) {
                    $(this).find("li").each(function () {
                        var perGbprice = $(this).find("span").text();
                        var clsname = $(this).attr("class");
                        $(".catalog_details .summary ul.price_calculator li").each(function () {
                            var gbinputVal = $(this).find(".form-control").val();
                            if ($(this).find(".form-control").attr("id") == clsname) {
                                var totalEstimate = gbinputVal * perGbprice;
                                sumofestimatecost += Number(totalEstimate);
                            }
                        });
                    });
                } else {
                    
                }
            } else {
               
            }
        });

        $(".catalog_details .summary .summary-body .estimateCost span").text(sumofestimatecost.toFixed(2));
        $(".catalog_details .summary .summary-body .existingCost span").text(sumofestimatecost.toFixed(2));
    }

    getClusterDetail() {
        let username="admin";
        let password="admin";
     
        let authorization="";
        const loginData = {
            method: 'POST',
            headers: new Headers({
                'Content-Type': 'application/json'
            }),
            body: JSON.stringify(
                {
                    "userid": "admin",
                    "password":"admin"
                }
            )  
        };
     
        fetch('https://10.151.35.44:30540/engine/api/v1/login',loginData)
        .then(response => {
     
            if (!response.ok) {
            console.log("response is not correct ");
            }
     
            return response.json();
        }).then(response => {
     
           authorization=response.token;
     
           let url='https://10.151.35.44:30540/engine/api/v1/robincluster';
     
           fetch(url,{
            method: 'GET',
            headers: new Headers({
                'Authorization': authorization,
            })
        })
        .then(response => {
     
            if (!response.ok) {
            }
            return response.json();
        }).then(response => {    
            this.setState({     
                 clusterName:response.items[0].eid
                });
            });
        });
    }

    componentDidMount() {
        this.getClusterDetail();    
        this.appConfiguration();
        this.estimatecost();
    }

    render() {
        return (

            <div>
                <nav className="navbar navbar-expand-lg fixed-top navbar-dark bg-pink" id="mainheader">
                    <div className="container">
                        <LogoComponent imagePath="/images/logo.png" />

                        <button className="navbar-toggler p-0 border-0" type="button" data-toggle="offcanvas">
                            <span className="navbar-toggler-icon" />
                        </button>

                        <div className="navbar-collapse offcanvas-collapse" id="navbarsExampleDefault">
                            <SearchComponent searchText="What are you looking for" />
                            <MyAccountComponent />
                            <CartComponent />
                            <NotificationComponent />
                        </div>
                    </div>
                </nav>
                <MenuComponent />
                <StickyiconComponent />

                <div className="bg-white">
                    <section className="catalog_details">
                        <div className="container">
                            <div className="row">
                                <div className="col-xl-9 col-lg-8">
                                    <nav aria-label="breadcrumb">
                                        <ol className="breadcrumb">
                                            <li className="breadcrumb-item"><a href="private_cloud_services.html">Catalog</a></li>
                                            <li className="breadcrumb-item active" aria-current="page">Software</li>
                                        </ol>
                                    </nav>
                                    <div className="catalog_header">
                                        <img src="./images/nginx.png" alt="NGINX" />
                                        <div className="description">
                                            <h3>{sessionStorage.getItem("selected-app")}</h3>
                                            <ul>
                                                <li><b>Author:</b>Sterlite</li>
                                                <li className="version"><b>Version:</b><span>1.19.1</span></li>
                                                <li><b>Date of Last update:</b>02/08/2020</li>
                                                <li><a href="javascript:void(0);">Get help?</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <ul className="nav nav-tabs" id="myTab" role="tablist">
                                        <li className="nav-item" role="presentation">
                                            <a className="nav-link active" id="Add-tab" data-toggle="tab" href="#add" role="tab" aria-controls="add" aria-selected="true">Modify</a>
                                        </li>
                                    </ul>
                                    <div className="tab-content" id="myTabContent">
                                        <div className="tab-pane fade show active" id="add" role="tabpanel" aria-labelledby="add-tab">
                                            <div className="row">
                                                <div className="col-xl-2 col-lg-3">
                                                    <ul className="category_ul">
                                                        <li>
                                                            <span>Type</span>
                                                            <p>Helm chart</p>
                                                        </li>
                                                        <li>
                                                            <span>Provider</span>
                                                            <p>Third party</p>
                                                        </li>
                                                        <li>
                                                            <span>Category</span>
                                                            <p>Developer Tools</p>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <div className="col-xl-9 col-lg-9">
                                                    <div className="targetMethod">
                                                        <div className="items">
                                                            <label>Select Your Target</label>
                                                            <div className="innerdiv">
                                                                <img src="./images/iks.svg" alt="Sterlite Kubernetes Service" />
                                                                <div className="title">
                                                                    <h4>Sterlite Kubernetes Service</h4>
                                                                </div>
                                                                <i className="fas fa-check-circle"></i>
                                                            </div>
                                                        </div>
                                                         </div>
                                                    <div className="pricing_plan">
                                                        <label>Pricing Plans</label>
                                                        <p>Displayed prices do not include tax. Monthly prices shown are for country or region: <a href="javascript:void(0);">United States</a></p>
                                                        <div className="plan_tbl">
                                                            <div className="container">
                                                                <div className="row d-none d-xl-flex">
                                                                    <div className="col-lg-2">
                                                                        <b>Plan</b>
                                                                    </div>
                                                                    <div className="col-lg-5">
                                                                        <b>Features</b>
                                                                    </div>
                                                                    <div className="col-lg-5">
                                                                        <b>Pricing</b>
                                                                    </div>
                                                                </div>
                                                                <div className="row">
                                                                    <div className="col-xl-2 col-lg-12">
                                                                        <b className="header_title">Plan</b>
                                                                        <b className="plan_title">Opensource</b>
                                                                    </div>
                                                                    <div className="col-xl-5 col-lg-12">

                                                                    </div>
                                                                    <div className="col-xl-4 col-lg-12">
                                                                        <b className="header_title">Pricing</b>
                                                                        <ul>
                                                                            <li>Free</li>
                                                                        </ul>
                                                                    </div>
                                                                    <div className="col-xl-1 col-lg-12">
                                                                        <i className="far fa-circle"></i>
                                                                        <i className="fas fa-check-circle d-none"></i>
                                                                    </div>
                                                                    <div className="col-xl-2 d-none d-xl-flex">

                                                                    </div>
                                                                    <div className="col-xl-10 col-lg-12">
                                                                        <hr className="mt-0" />
                                                                        <p>High availability will not be available with free plan. Free plan includes 10GB disk storage, 1 GB RAM. Backup storage and dedicated cpu is not available with Starter plan.</p>
                                                                    </div>
                                                                </div>
                                                                <div className="row activCls">
                                                                    <div className="col-xl-2 col-lg-12">
                                                                        <b className="header_title">Plan</b>
                                                                        <b className="plan_title">Plus</b>
                                                                    </div>
                                                                    <div className="col-xl-5 col-lg-12">
                                                                        <b className="header_title">Features</b>
                                                                        <b>Advanced monitoring and high availability</b>
                                                                    </div>
                                                                    <div className="col-xl-4 col-lg-12">
                                                                        <b className="header_title">Pricing</b>
                                                                        <ul className="plan_price">
                                                                            <li className="gbdisk"><b className="currency"></b><span>0.58</span>/GB-Disk</li>
                                                                            <li className="gbram"><b className="currency"></b><span>8.50</span>/GB-RAM</li>
                                                                            <li className="gbbackups"><b className="currency"></b><span>0.03</span>/GB-Backups</li>
                                                                            <li className="vpc"><b className="currency"></b><span>45.00</span>/Virtual Processor Core</li>
                                                                        </ul>
                                                                    </div>
                                                                    <div className="col-xl-1 col-lg-12">
                                                                        <i className="far fa-circle d-none"></i>
                                                                        <i className="fas fa-check-circle"></i>
                                                                    </div>
                                                                    <div className="col-xl-2 d-none d-xl-flex">

                                                                    </div>
                                                                    <div className="col-xl-10 col-lg-12">
                                                                        <hr className="mt-0" />
                                                                        <p>PLUS description : NGINX Plus has exclusive enterprise‑grade features beyond what's available in the open source offering, including session persistence, configuration via API, and active health checks. Use NGINX Plus instead of your hardware load balancer and get the freedom to innovate without being constrained by infrastructure.</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <form>
                                                            <div className="form-row">
                                                                <div className="form-group col-xl-12 col-lg-12">
                                                                    <label>Select CPU allocation</label>
                                                                    <p className="mb-0">CPU allocation is optional. Selecting CPU allocation ensures your database has dedicated compute resources for your workload.</p>
                                                                    <div className="input-group mb-2">
                                                                        <input type="number" className="form-control" min="0" id="vpc1" placeholder="Select CPU allocation" defaultValue="2" />
                                                                        <div className="input-group-prepend">
                                                                            <div className="input-group-text">vCPU</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div className="form-group col-xl-6 col-lg-12">
                                                                    <label>Select memory allocation</label>
                                                                    <div className="input-group mb-2">
                                                                        <input type="number" className="form-control" min="0" id="gbram1" placeholder="Select memory allocation" value="2" />
                                                                        <div className="input-group-prepend">
                                                                            <div className="input-group-text">GB</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div className="form-group col-xl-6 col-lg-12">
                                                                    <label>Select disk allocation</label>
                                                                    <div className="input-group mb-2">
                                                                        <input type="number" className="form-control" min="0" id="gbdisk1" placeholder="Select disk allocation" value="2" />
                                                                        <div className="input-group-prepend">
                                                                            <div className="input-group-text">GB</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div className="form-row">
                                                                <div className="form-group col-xl-6 col-lg-12">
                                                                    <label>Kubernetes cluster <i className="fas fa-info-circle" data-toggle="tooltip" data-placement="top" title="A cluster is required for your installation. It is recommended to install only one instance per cluster."></i></label>
                                                                    <input type="text" className="form-control" id="cluster-name" value="No cluster available" disabled />
                                                                </div>
                                                                <div className="form-group col-xl-6 col-lg-12">
                                                                    <label>Namespace <i className="fas fa-info-circle" data-toggle="tooltip" data-placement="top" title="Select from an existing namespace or create a new one by entering a unique namespace name."></i></label>
                                                                    <input type="text" id="deployed-namespace" className="form-control" defaultValue="Sterlite Kubernetes Service" />
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-xl-3 col-lg-4">
                                    <div className="summary">
                                        <h4>Summary</h4>
                                        <hr className="bg-white" />
                                        <div className="summary-body">
                                            <h4 className="title">NGINX</h4>
                                            <ul className="plan">
                                                <li><span>Target:</span><b className="target_namespace">{this.state.namespace}</b></li>
                                                <li><span>Method:</span><b className="method">Helm chart</b></li>
                                                <li><span>Kubernetes cluster:</span><b className="cluster">Robin-cluster</b></li>
                                                <li><span>Name:</span><b className="workspace">nginx-08-04-2020</b></li>
                                                <li><span>Resource group:</span><b className="resourceGroup">Default</b></li>
                                            </ul>
                                            <ul className="price_calculator">
                                                <li>
                                                    <label>GB-Disk</label>
                                                    <input type="number" id="gbdisk" min="0" className="form-control" defaultValue="1" />
                                                </li>
                                                <li>
                                                    <label>GB-RAM</label>
                                                    <input type="number" id="gbram" min="0" className="form-control" defaultValue="1" />
                                                </li>
                                                <li>
                                                    <label>GB-Backups</label>
                                                    <input type="number" id="gbbackups" min="0" className="form-control" defaultValue="0" readOnly />
                                                </li>
                                                <li>
                                                    <label>Virtual Processor Core</label>
                                                    <input type="number" id="vpc" min="0" className="form-control" defaultValue="1" />
                                                </li>
                                            </ul>
                                            
                                            <div className="estimateCost">
                                                <label className="pr-2 mr-auto">Estimated Cost:</label>
                                                <b className="currency"></b><span>0.00</span><b>/month</b>
                                            </div>
                                            <div className="existingCost d-flex bg-white text-body px-3">
                                                <label className="pr-2 mr-auto">Existing Cost:</label>
                                                <b className="currency"></b><span className="font-weight-bold">54.11</span><b>/month</b>
                                            </div>
                                            <div className="priceChange d-flex bg-white text-body px-3">
                                                <label className="pr-2 mr-auto">Price Change:</label>
                                                <b className="currency"></b><span className="font-weight-bold">0.00</span><b>/month</b>
                                            </div>
                                            <p className="includeTax">Estimated cost doesn't include tax</p>
                                        </div>
                                        <div className="summary-footer">
                                            <label className="form-check-label text-white">I have read and agree to the following license agreements:
                                    <input className="form-check-input" type="checkbox" />
                                                <span className="checkmark"></span>
                                            </label>
                                            <a href="/updateRobinApplication" className="btn btn-pink d-block withoutRadiusBorder disabled" onClick={this.save_details}>Proceed to Modify</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </section>
                </div>


                <FooterComponent />
            </div>

        );
    }
}

export default ViewNgInxPlusComponent;