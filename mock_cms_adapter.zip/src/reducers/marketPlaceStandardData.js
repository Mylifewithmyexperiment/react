import {
  SEARCH_BOX_COMPONENT_DATA,
  LOGO_COMPONENT_DATA,
  HEADERLINK_COMPONENT_DATA,
} from "../actionTypes";

const initialstate = {
  name: "",
   data:""
};

const marketPlaceStandardData = (state = initialstate, action) => {
  switch (action.type) {
   
    case SEARCH_BOX_COMPONENT_DATA:
      return {
        ...state,
        details: action.params,
      };
    case LOGO_COMPONENT_DATA:
      return {
        ...state,
      };
    case HEADERLINK_COMPONENT_DATA:
      return {
        ...state,
      };
    default:
      return state;
  }
};

export default marketPlaceStandardData;
