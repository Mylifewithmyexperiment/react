import React from "react";
import { sendHeaderComponentData } from "../action/index";
import { connect } from "react-redux";

class SearchBox extends React.Component {

  sendHomeDetails=()=>{
    sendHeaderComponentData("new Data from search Box")
  }

  render() {
    return (
      <div>
        <h1> search box component </h1>
        <button onClick={this.sendHomeDetails}></button>{" "}
      </div>
    );
  }
}

const mapdispatchtoprop = { sendHeaderComponentData };
const mapstatetoprpo = (state)=>({
  abc:state.sendHomeDetails
 });
export default connect(mapstatetoprpo, mapdispatchtoprop)(SearchBox);
