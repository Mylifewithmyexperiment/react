import React from 'react';

class Logo extends React.Component{

 render(){

    return( <h1> LOGO</h1> );
 }



}
export default Logo;