import React from "react";
class HomePage extends React.Component {
  render() {
    return <div>homepage</div>;
  }
}
export default HomePage;
