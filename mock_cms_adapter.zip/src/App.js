import React from "react";
import Logo from "./component/Logo";
import HomePage from "./component/HomePage";
import SearchBox from "./component/SearchBox";
import "./App.css";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import HeaderLinks from "./component/HeaderLinks";
import mockCMSAdapter from "./adapter/mockCMSAdapter";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as Actions from "./action/index";


const mapStateToProps = (state) => ({
  marketPlaceStandardData: state.marketPlaceStandardData,
});

const mapDispatchToProps = (dispatch) => ({
  actions: bindActionCreators(Actions, dispatch),
});

function App() {
  return (
    <div className="App">
      <Router>
        <Switch>
          <Route exact path="/" component={HomePage}></Route>
          <Route exact path="/logo" component={Logo}></Route>
          <Route exact path="/searchbox" component={SearchBox}></Route>
          <Route exact path="/adapter" component={mockCMSAdapter}></Route>
          <Route exact path="/headerlink" component={HeaderLinks}></Route>
        </Switch>
      </Router>
    </div>
  );
}

export default connect(mapStateToProps, mapDispatchToProps)(App);
