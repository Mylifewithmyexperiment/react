import React from "react";
import { connect } from "react-redux";
import content from "../resources/mock_cms.json";
import HeaderLinks from "../component/HeaderLinks";
//import { dispatch } from "redux";
import * as Actions from "../action";
import { bindActionCreators } from "redux";
import {
  sendSearchBoxComponentData,
  sendLogoComponentData,
  sendHeaderComponentData,
} from "../action/index";

class mockCMSAdapter extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      contentSlot: content.contentSlots.contentSlot,
    };
  }

  sendHomedetails=()=>{

  }


  render() {
    for (let index = 0; index < this.state.contentSlot.length; index++) {

      switch (this.state.contentSlot[index].name) {
        case 'Search Box':
        //  sendHomedetails=()=>{
            sendSearchBoxComponentData(this.state.contentSlot[index]);
         // };
         
          break;
      
        default:
          break;
      }


      // if (this.state.contentSlot[index].name === "Search Box") {
      //   const searchBox = this.state.contentSlot[index];
        
      //   sendSearchBoxComponentData(searchBox);
      // }

      if (this.state.contentSlot[index].name === "Header links") {
        const headerLink = this.state.contentSlot[index];
        sendHeaderComponentData(headerLink);
      }

      if (this.state.contentSlot[index].slotId === "SiteLogoSlot") {
        const SiteLogoSlot = this.state.contentSlot[index];
        sendLogoComponentData(SiteLogoSlot);
      }
    }

    return (
      <div>adapter class
        <button onClick={this.sendHomedetails}
         ></button>
        <HeaderLinks contentSlotData={this.headerLink} />
      </div>
    );
  }
}

// const mapDispatchToProps = {
//   sendSearchBoxComponentData,
//   sendLogoComponentData,
 
//   sendHeaderComponentData,
// };

// const mapDispatchToProps = dispatch => {
//   return {
//      onAction: () => dispatch(sendSearchBoxComponentData,sendLogoComponentData,sendHeaderComponentData),
//   }
// }


const mapDispatchToProps = (dispatch) => ({
  actions: bindActionCreators(Actions, dispatch),
});

const mapstatetoprop = (state)=>({
pqr : state.sendHomedetails
});
export default connect(mapstatetoprop,mapDispatchToProps)(mockCMSAdapter);
 