import { createStore } from "redux";
import { persistStore, persistReducer } from "redux-persist";
import storage from "redux-persist/lib/storage";
import AddAllReducers from "./reducers";

//import autoMergeLevel2 from 'redux-persist/lib/stateReconciler/autoMergeLevel2';



// const persistConfig = {
//   key: 'root',
//   storage: storage,
//   stateReconciler: autoMergeLevel2 // see "Merge Process" section for details.
//  };
 
//  const pReducer = persistReducer(persistConfig, AddAllReducers);
 
//  export const store = createStore(pReducer);
//  export const persistor = persistStore(store);










// const persistConfig = {
//   key: 'root',
//   storage,
// }

// const persistedReducer = persistReducer(persistConfig, AddAllReducers)

 
//   let store = createStore(persistedReducer,window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__())
//   let persistor = persistStore(store)
//   export  { store, persistor }
 


const persistConfig = {
  key: "root",
  storage,
  timeout: null 
}; 
const persistedReducer = persistReducer(persistConfig, AddAllReducers);

const store = createStore( persistedReducer, 
  window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
);

let persistor = persistStore(store);

export { store, persistor };
