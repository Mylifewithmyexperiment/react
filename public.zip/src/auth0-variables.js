export const AUTH_CONFIG = {
    domain: "blog-samples.auth0.com",
    roleUrl: "https://rbac-tutorial-app/role",
    clientId: "UjxVUFKrlOtD5LMo2Tq5vtlDAx1c5ugX",
    callbackUrl: "http://localhost:3000/callback"
  };




